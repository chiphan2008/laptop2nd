@extends("layouts.admin")


@section('content')
<div class="right_col" role="main">
          

          
</div>
@endsection